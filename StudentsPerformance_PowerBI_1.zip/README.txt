HOW TO OPEN
1. Unzip this folder.
2. Double-click StudentsPerformance.pbip  (opens in Power BI Desktop).
   - If Desktop complains, enable: File > Options > Preview features >
     "Power BI Project (.pbip) save option", "Store semantic model using TMDL format",
     "Store reports using enhanced metadata format (PBIR)", then restart and reopen.
3. File > Save as to create a normal .pbix if you want a single file to submit.

The 1,000 rows are embedded inside the model, so no file path needs fixing.
data/ holds the original cleaned CSV and the enriched CSV (adds Student ID, Total/Average Score, Performance Band).

FALLBACK (if the .pbip will not open)
Get data > Text/CSV > data/StudentsPerformance_Enriched.csv > Load, then add the measures
from the Students.tmdl file (each "measure" line is a DAX measure).

PERFORMANCE BANDS: Excellent >= 85 | Good 70-84.99 | Average 55-69.99 | Needs Support < 55 (on average of 3 scores)
